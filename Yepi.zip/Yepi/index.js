const Discord = require('discord.js');
const yepi = new Discord.Client();

yepi.login('NTkxNjk4NzY5OTgwOTQ4NDgx.XQ0l7Q.j0lPdLz_L4Ry1DFVWnBrl8z6_iw');

yepi.on('message', message => {
let responseObject = {
    ".ola" : "Olá, nobre aventureiro!, como estás?",
    ".falar" : "@everyone prestem atenção que o usuario quer falar!"
};

if(responseObject[message.content]){
    message.channel.send(responseObject[message.content]);
}
});